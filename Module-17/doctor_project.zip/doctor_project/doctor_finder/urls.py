from django.urls import path
from .views import (
    DoctorListCreateView,
    DoctorRetrieveUpdateDeleteView ,
    LoginView ,
    weather_view,
    geocode_view ,
    github_repos,
    twitter_view,
    country_view,
    send_otp_view,
    verify_otp_view,
    otp_form_view,
    book_appointment,
    create_paypal_for_appointment,
    capture_appointment_payment,
    joke_api_view
    

)

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),
    path('doctors/', DoctorListCreateView.as_view()),
    path('doctors/<int:pk>/', DoctorRetrieveUpdateDeleteView.as_view()),

    # Weather
    path('weather/', weather_view),
    path('geocode/', geocode_view),
    path('github/repos/', github_repos),
    path('twitter/<str:username>/', twitter_view),
    path('country/<str:name>/', country_view),
    path('send-otp/', send_otp_view),
    path('verify-otp/', verify_otp_view),
    path('otp-form/', otp_form_view),

    path('appointments/book/', book_appointment),
    path('appointments/<int:appointment_id>/paypal/', create_paypal_for_appointment),
    path('appointments/<int:appointment_id>/capture/', capture_appointment_payment),

    path('joke/', joke_api_view),



]
