from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from django.conf import settings


def send_confirmation_email(to_email, username):
    message = Mail(
        from_email=settings.DEFAULT_FROM_EMAIL,
        to_emails=to_email,
        subject='Registration Successful',
        html_content=f"""
            <h3>Hello {username},</h3>
            <p>Your registration was successful.</p>
            <p>Thank you for using Doctor Finder.</p>
        """
    )

    try:
        sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
        sg.send(message)
        return True
    except Exception as e:
        print(str(e))
        return False
