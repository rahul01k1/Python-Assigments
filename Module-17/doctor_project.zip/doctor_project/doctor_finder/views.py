from rest_framework.generics import ListCreateAPIView , RetrieveUpdateDestroyAPIView
from .models import Doctor , Order , Appointment
from .serializers import DoctorSerializer
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
import requests
from rest_framework.permissions import IsAuthenticated
from django.conf import settings
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view, permission_classes
from .utils import send_otp
from .email_utils import send_confirmation_email
from django.shortcuts import render
from .paypal_utils import get_paypal_access_token

def otp_form_view(request):
    return render(request, 'otp_form.html')


class DoctorListCreateView(ListCreateAPIView):
    queryset = Doctor.objects.all().order_by("-created_at")
    serializer_class = DoctorSerializer

class DoctorRetrieveUpdateDeleteView(RetrieveUpdateDestroyAPIView):
    queryset = Doctor.objects.all()
    serializer_class = DoctorSerializer

class LoginView(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(
            data=request.data,
            context={'request': request}
        )
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)

        return Response({
            'token': token.key,
            'user_id': user.id,
            'username': user.username
        })

from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view, permission_classes

@api_view(['GET'])
@permission_classes([AllowAny])
def weather_view(request):
    city = request.GET.get('city')
    if not city:
        return Response({'error': 'City is required'}, status=400)

    url = (
        f"https://api.openweathermap.org/data/2.5/weather"
        f"?q={city}&appid={settings.OPENWEATHER_API_KEY}&units=metric"
    )

    response = requests.get(url)
    return Response(response.json())


@api_view(['GET'])
def geocode_view(request):
    address = request.GET.get('address')
    if not address:
        return Response({'error': 'Address is required'}, status=400)

    url = (
        f"https://maps.googleapis.com/maps/api/geocode/json"
        f"?address={address}&key={settings.GOOGLE_MAPS_API_KEY}"
    )

    response = requests.get(url)
    return Response(response.json())

@api_view(['GET', 'POST'])
def github_repos(request):
    headers = {
        "Authorization": f"token {settings.GITHUB_TOKEN}"
    }

    if request.method == 'GET':
        url = "https://api.github.com/user/repos"
        response = requests.get(url, headers=headers)
        return Response(response.json())

    if request.method == 'POST':
        repo_name = request.data.get('name')
        url = "https://api.github.com/user/repos"
        data = {"name": repo_name}
        response = requests.post(url, json=data, headers=headers)
        return Response(response.json())

@api_view(['GET'])
@permission_classes([AllowAny])
def twitter_view(request, username):
    headers = {
        "Authorization": f"Bearer {settings.TWITTER_BEARER_TOKEN}"
    }

    url = (
        f"https://api.twitter.com/2/tweets/search/recent"
        f"?query=from:{username}&max_results=5"
    )

    response = requests.get(url, headers=headers)
    return Response(response.json())


@api_view(['GET'])
@permission_classes([AllowAny])
def country_view(request, name):
    url = f"https://restcountries.com/v3.1/name/{name}"
    response = requests.get(url)
    return Response(response.json())




OTP_STORE = {}


@api_view(['POST'])
@permission_classes([AllowAny])
def send_otp_view(request):
    phone = request.data.get('phone')

    if not phone:
        return Response({'error': 'Phone number required'}, status=400)

    otp = send_otp(phone)
    OTP_STORE[phone] = otp

    return Response({'message': 'OTP sent successfully'})
@api_view(['POST'])
@permission_classes([AllowAny])
def verify_otp_view(request):
    phone = request.data.get('phone') or request.POST.get('phone')
    otp = request.data.get('otp') or request.POST.get('otp')
    email = request.data.get('email') or request.POST.get('email')
    username = request.data.get('username') or request.POST.get('username')

    print("OTP_STORE:", OTP_STORE)
    print("INPUT:", phone, otp)

    if not all([phone, otp, email, username]):
        return Response(
            {'error': 'phone, otp, email, username required'},
            status=400
        )

    try:
        otp = int(otp)
    except ValueError:
        return Response({'error': 'OTP must be numeric'}, status=400)

    if OTP_STORE.get(phone) == otp:
        send_confirmation_email(email, username)
        del OTP_STORE[phone]  # cleanup
        return Response({'message': 'OTP verified and email sent'})

    return Response({'error': 'Invalid or expired OTP'}, status=400)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def book_appointment(request):
    doctor_id = request.data.get('doctor_id')
    date = request.data.get('date')
    time = request.data.get('time')

    doctor = Doctor.objects.get(id=doctor_id)

    appointment = Appointment.objects.create(
        user=request.user,
        doctor=doctor,
        appointment_date=date,
        appointment_time=time,
        consultation_fee=doctor.consultation_fee,
        status='pending'
    )

    return Response({
        "appointment_id": appointment.id,
        "amount": str(appointment.consultation_fee)
    })

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_paypal_for_appointment(request, appointment_id):
    appointment = Appointment.objects.get(id=appointment_id)
    token = get_paypal_access_token()

    url = f"{settings.PAYPAL_BASE_URL}/v2/checkout/orders"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    payload = {
        "intent": "CAPTURE",
        "purchase_units": [{
            "amount": {
                "currency_code": "USD",
                "value": str(appointment.consultation_fee)
            }
        }]
    }

    response = requests.post(url, json=payload, headers=headers)
    data = response.json()

    appointment.paypal_order_id = data["id"]
    appointment.save()

    return Response(data)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def capture_appointment_payment(request, appointment_id):
    appointment = Appointment.objects.get(id=appointment_id)
    token = get_paypal_access_token()

    url = f"{settings.PAYPAL_BASE_URL}/v2/checkout/orders/{appointment.paypal_order_id}/capture"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    response = requests.post(url, headers=headers)
    data = response.json()

    if data.get("status") == "COMPLETED":
        appointment.payment_status = 'paid'
        appointment.status = 'confirmed'
    else:
        appointment.payment_status = 'failed'

    appointment.save()
    return Response(data)


@api_view(['GET'])
@permission_classes([AllowAny])
def joke_api_view(request):
    category = request.GET.get('category', 'Any')
    url = f"https://v2.jokeapi.dev/joke/{category}"

    response = requests.get(url)
    data = response.json()

    if data.get("type") == "single":
        return Response({
            "joke": data.get("joke")
        })

    return Response({
        "setup": data.get("setup"),
        "delivery": data.get("delivery")
    })
